var hunger=100;
var energy=50;
var treat=50;


function feed(){
    if(hunger>0){
    display();    
    hunger=hunger-10;
    
    }
    if(energy<100){
    energy=energy+10;
    display();
    }
    if(treat>100){
    display();
    treat=treat-10
    }
}

function display(){
    document.getElementById(`info-c1`).innerHTML=`
    <p><b>hunger:</b> ${hunger}%</p>
    <p><b>energy:</b> ${energy}%</p>
    <p><b>treat:<b> ${energy}%</p>
    `;
}
function init(){
display();
}
window.onload = init;
